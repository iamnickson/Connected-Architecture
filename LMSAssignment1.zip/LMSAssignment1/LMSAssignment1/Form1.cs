﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;

namespace LMSAssignment1
{
    public partial class Form1 : Form
    {
        MySqlConnection mycon = new MySqlConnection("server=localhost; User Id=root; database=employee");
        public Form1()
        {
            InitializeComponent();
            //poulateTable();
        }
        private void poulateTable()
        {
            mycon.Open();
            using (mycon)
            {
                MySqlCommand cmd = new MySqlCommand("SELECT * FROM employee", mycon);
                cmd.ExecuteNonQuery();
                using (MySqlDataReader mrdr = cmd.ExecuteReader())
                {
                    DataTable employee = new DataTable();
                    employee.Columns.Add("Emp_ID");
                    employee.Columns.Add("Emp_Name");
                    employee.Columns.Add("Salary");
                    while (mrdr.Read())
                    {
                        DataRow drow = employee.NewRow();
                        drow["Emp_ID"] = mrdr["emp_id"];
                        drow["Emp_Name"] = mrdr["em_name"];
                        drow["Salary"] = mrdr["salary"];
                        employee.Rows.Add(drow);
                    }
                    DataGridView1.DataSource = employee;
                }
            }
            mycon.Close();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string empid = TextBox1.Text;
            string empname = TextBox2.Text;
            string salary = TextBox3.Text;
            //Double price = Convert.ToDouble(TextBox3.Text);

            //System.Windows.Forms.MessageBox.Show(empid);
            //System.Windows.Forms.MessageBox.Show(empname);

            //MySqlConnection mycon = new MySqlConnection("server=localhost; User Id=root; database=employee");
            mycon.Open();
            using (mycon)
            {
                MySqlCommand insert = new MySqlCommand("INSERT INTO `employee`(`emp_id`, `em_name`, `salary`) VALUES ('"+empid+"','"+empname+"','"+salary+"')", mycon);
                int result=insert.ExecuteNonQuery();
                //int result = insert.ExecuteNonQuery();
                if (result < 1)
                {
                    System.Windows.Forms.MessageBox.Show("Insertion failed");
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Inserted Successfully");
                }
                mycon.Close();
            }
            poulateTable();
            TextBox1.Text="";
            TextBox2.Text="";
            TextBox3.Text="";
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            string empid = TextBox1.Text;
            mycon.Open();
            using (mycon)
            {
                MySqlCommand delete = new MySqlCommand("DELETE FROM `employee` WHERE `emp_id`='" + empid+"'", mycon);
                int result = delete.ExecuteNonQuery();
                //int result = insert.ExecuteNonQuery();
                if (result < 1)
                {
                    System.Windows.Forms.MessageBox.Show("Data has not been deleted");
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Employee data having id " + empid + " has been deleted Successfully");
                }
                mycon.Close();
            }
            poulateTable();
            TextBox1.Text = "";
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            string empid = TextBox1.Text;
            string empname = TextBox2.Text;
            string salary = TextBox3.Text;
            mycon.Open();
            using (mycon)
            {
                MySqlCommand update = new MySqlCommand("UPDATE `employee` SET `em_name`='"+empname+"',`salary`='"+salary+"' WHERE `emp_id`='"+empid+"'", mycon);
                int result = update.ExecuteNonQuery();
                //int result = insert.ExecuteNonQuery();
                if (result < 1)
                {
                    System.Windows.Forms.MessageBox.Show("Data has not been updated");
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Employee data having id " + empid + " has been updated Successfully");
                }
                mycon.Close();
            }
            poulateTable();
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            poulateTable();
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            string empid = TextBox1.Text;
            mycon.Open();
            using (mycon)
            {
                MySqlCommand search = new MySqlCommand("SELECT * FROM `employee` WHERE `emp_id`='" + empid + "'", mycon);
                int result = search.ExecuteNonQuery();
                //int result = insert.ExecuteNonQuery();
                if (result < 1)
                {
                    System.Windows.Forms.MessageBox.Show("Employee not found");
                }
                else
                {
                    search.ExecuteNonQuery();
                    using (MySqlDataReader mrdr = search.ExecuteReader())
                    {
                        DataTable employee = new DataTable();
                        employee.Columns.Add("Emp_ID");
                        employee.Columns.Add("Emp_Name");
                        employee.Columns.Add("Salary");
                        while (mrdr.Read())
                        {
                            DataRow drow = employee.NewRow();
                            drow["Emp_ID"] = mrdr["emp_id"];
                            drow["Emp_Name"] = mrdr["em_name"];
                            drow["Salary"] = mrdr["salary"];
                            employee.Rows.Add(drow);
                        }
                        DataGridView1.DataSource = employee;
                    }
                }
            }
            mycon.Close();
            TextBox1.Text = "";
        }

        private void Button6_Click(object sender, EventArgs e)
        {
            mycon.Open();
            using (mycon)
            {
                MySqlCommand count = new MySqlCommand("SELECT COUNT(emp_id) FROM employee", mycon);
                count.ExecuteNonQuery();
                Object temp = count.ExecuteScalar();
                Label4.Text = temp.ToString();
                mycon.Close();
            }
        }

        private void Button7_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
